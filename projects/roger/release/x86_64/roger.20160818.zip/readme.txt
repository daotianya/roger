1, start server
	./roger_server > /dev/null &

2, start client
	roger.exe ip port

3, setup proxy on browser side
	http proxy address: http://127.0.0.1:8088/proxy.pac
	socks5 proxy address: 127.0.0.1 12122

